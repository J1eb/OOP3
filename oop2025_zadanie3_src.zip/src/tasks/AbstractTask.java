package tasks;

public abstract class AbstractTask {

}
