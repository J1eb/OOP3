package tasks;

public class RecurringTask extends AbstractTask {

}
