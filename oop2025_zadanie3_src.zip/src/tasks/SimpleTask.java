package tasks;

public class SimpleTask extends AbstractTask{

}
